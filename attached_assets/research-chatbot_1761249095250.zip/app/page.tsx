import { ChatContainer } from "@/components/chat-container"

export default function Home() {
  return <ChatContainer />
}
